class Tovar_Plat(name1:String,T:Int,P:Int):OneTovar(name1,T,P) {
    fun God()
    {
    println("Введите текущий год")
    T = readLine()!!.toInt()
    println("Введите год выпуска товара")
    P = readLine()!!.toInt()
}
    var Qp1:Double=0.0
    override fun Qp():Double
    {
        if(T<P)
            println("Введите ещё раз, текущий год должен быть больше года выпуска")
       else
            Qp1=Q()+0.5+(T-P)
        return Qp1

    }
}