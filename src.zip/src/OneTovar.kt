open class OneTovar(var name1:String,var T1:Int,var P1:Int):Tovar()
{
    override var price=0.0
    override var name=name1
    override var k=0
    override var T=T1
    override var P=P1
    override fun Q():Double{
        var Q=price/k
        return Q
    }
    override fun Qp():Double
    {
         return 0.0
    }
fun Input()
{
        do {
            println("Введите стоимость товара")
            price = readLine()!!.toDouble()
        }while(price<=0)
        do {
            println("Введите кол-во товара")
            k = readLine()!!.toInt()
        }while(k<=0)

}
}