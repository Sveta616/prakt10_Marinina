abstract class Tovar():InfoTovar {
    abstract var name:String
    abstract var price:Double
    abstract var k:Int
    abstract fun Q():Double
    abstract fun Qp():Double
    abstract var T:Int
    abstract var P:Int
    override fun Info()
    {
        println("Название товара:$name\nСтоимость товара:$price\nКол-во товара:$k\nТекущий год:$T\nГод выпуска товара:$P\nСтоимость одного товара Q=${String.format("%.2f",Q())}\nПлата Qp=${String.format("%.2f",Qp())}")
    }

}