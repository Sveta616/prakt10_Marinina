interface InfoTovar {
    fun Info()
}