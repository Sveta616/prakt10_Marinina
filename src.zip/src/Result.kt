fun main()
{
    try {
        var tv = Tovar_Plat("Шкаф", 0, 0)
        tv.Input()
        tv.God()
        tv.Info()
        tv.Q()
        tv.Qp()
    }catch(e:Exception)
    {
        println("Введите данные корректно")
    }
}